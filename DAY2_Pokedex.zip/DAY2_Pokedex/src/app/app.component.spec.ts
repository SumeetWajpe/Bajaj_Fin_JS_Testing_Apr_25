import { TestBed } from "@angular/core/testing";
import { AppComponent } from "./app.component";
import { RouterTestingModule } from "@angular/router/testing";
import { LoaderService } from "./shared/services/loader.service";
import { DebugElement } from "@angular/core";
import { By } from "@angular/platform-browser";

describe("test suites for App Component", () => {
  let el: DebugElement;
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AppComponent],
      providers: [LoaderService],
      imports: [RouterTestingModule],
    }).compileComponents(); // compileComponents - compile the component template and css
  });

  it("should create the app component instance", () => {
    const fixture = TestBed.createComponent(AppComponent); // fixture - metadata along with component instance (zone,change detection)

    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });

  it("tests if title is set to pokedex-angular", () => {
    const fixture = TestBed.createComponent(AppComponent); // fixture - metadata along with component instance (zone,change detection)
    const app = fixture.componentInstance;
    expect(app.title).toEqual("pokedex-angular");
  });
  it("tests h1 with header class is created", () => {
    // nativeElement() returns DOM tree
    // debugElement is Angular object (js object) and has additional methods to reference or investigate the component
    const fixture = TestBed.createComponent(AppComponent); // fixture - metadata along with component instance (zone,change detection)
    el = fixture.debugElement;

    // 1st way - using native way (DOM APIs directly)
    // const h1 = el.nativeElement.querySelector("h1.header");
    // expect(h1).toBeTruthy();

    // 2nd way - (By using Browser specific API)
    let h1 = el.query(By.css(".header"));
    expect(h1).toBeTruthy();

    // const app = fixture.componentInstance;
    // expect(app.title).toEqual("pokedex-angular");
  });
});
