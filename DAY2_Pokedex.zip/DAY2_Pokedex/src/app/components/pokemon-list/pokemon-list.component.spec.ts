import { ComponentFixture, TestBed } from "@angular/core/testing";
import { PokemonListComponent } from "./pokemon-list.component";
import { PokemonItemComponent } from "../pokemon-item/pokemon-item.component";
import { FilterPokemonPipe } from "../../shared/pipes/filter-pokemon.pipe";
import { HeaderComponent } from "../../shared/components/header/header.component";
import { StatsFilterComponent } from "../../shared/components/stats-filter/stats-filter.component";
import { DialogComponent } from "../../shared/components/dialog/dialog.component";
import { PokemonDetailsComponent } from "../pokemon-details/pokemon-details.component";
import {
  HttpClientTestingModule,
  HttpTestingController,
} from "@angular/common/http/testing";
import { PokemonService } from "../../shared/services/pokemon.service";
import { FormsModule } from "@angular/forms";
import { NgMultiSelectDropDownModule } from "ng-multiselect-dropdown";
import { of } from "rxjs";
describe("test suites for App Component", () => {
  let fixture: ComponentFixture<PokemonListComponent>;
  let component: PokemonListComponent;
  let pokemonService: PokemonService;
  let httpMock: HttpTestingController;
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [
        PokemonListComponent,
        PokemonItemComponent,
        FilterPokemonPipe,
        HeaderComponent,
        StatsFilterComponent,
        DialogComponent,
        PokemonDetailsComponent,
      ],
      providers: [PokemonService],
      imports: [
        HttpClientTestingModule,
        FormsModule,
        NgMultiSelectDropDownModule,
      ],
    }).compileComponents(); // compileComponents - compile the component template and css
    httpMock = TestBed.inject(HttpTestingController);
    // HttpTestingController - mock backend for testing HTTP requests
  });
  beforeEach(() => {
    fixture = TestBed.createComponent(PokemonListComponent);
    component = fixture.componentInstance;
    pokemonService = TestBed.inject(PokemonService);
    fixture.detectChanges(); // trigger initial data binding
  });

  it("tests for service to be created", () => {
    let instance = fixture.debugElement.injector.get(PokemonService); // gives an access to service instance that is injected in the component
    expect(instance).toBeTruthy();
  });
  it("spies on getPokemonData method", () => {
    component.pokemonCount = 2;
    component.pokemonList = [{ name: "pokemon1" }];

    jest
      .spyOn(pokemonService, "getPokemonData")
      .mockReturnValue(of({ count: 2, results: [{ name: "pokemon1" }] }));
    component.getPokemonList();
    expect(pokemonService.getPokemonData).toHaveBeenCalled();
  });
});
