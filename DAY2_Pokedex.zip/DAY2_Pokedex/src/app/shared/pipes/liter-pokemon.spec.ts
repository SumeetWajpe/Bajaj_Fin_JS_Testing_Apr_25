import { TestBed } from "@angular/core/testing";
import { PokemonService } from "../services/pokemon.service";
import { FilterPokemonPipe } from "./filter-pokemon.pipe";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { NO_ERRORS_SCHEMA } from "@angular/core";

describe("test stuite for Filter Pokemon Pipe", () => {
  let pipe: FilterPokemonPipe;
  let pokemonService: any;
  let pokeMonServObj: PokemonService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [PokemonService],
      schemas: [NO_ERRORS_SCHEMA],
    });
    pokeMonServObj = TestBed.inject(PokemonService);

    // pokemonService = jest.spyOn(pokeMonServObj, "getPokemonGender");
    pipe = new FilterPokemonPipe(pokemonService);
  });
  it("should return the input array if no filters are applied", () => {
    const pokemonArr = [
      {
        id: 1,
        name: "Bulbasaur",
        types: [{ type: { name: "grass" } }],
      },
      {
        id: 2,
        name: "Charmander",
        types: [{ type: { name: "fire" } }],
      },
      {
        id: 3,
        name: "Squirtle",
        types: [{ type: { name: "water" } }],
      },
    ];
    const args = { searchText: "", types: [], genders: [] };
    expect(pipe.transform(pokemonArr, args)).toEqual(pokemonArr);
  });
  it("should return the searched array with searched text", () => {
    const pokemonArr = [
      {
        id: 1,
        name: "Bulbasaur",
        types: [{ type: { name: "grass" } }],
      },
      {
        id: 2,
        name: "Charmander",
        types: [{ type: { name: "fire" } }],
      },
      {
        id: 3,
        name: "Squirtle",
        types: [{ type: { name: "water" } }],
      },
    ];
    const args = { searchText: "bulb", types: [], genders: [] };
    const mockOutput = [
      {
        id: 1,
        name: "Bulbasaur",
        types: [{ type: { name: "grass" } }],
      },
    ];
    expect(pipe.transform(pokemonArr, args)).toEqual(mockOutput);
  });
});
